---
layout: post
title:  "Toy Project"
info: "toy project"
tech: "python"
type: Toy 
---

## Toy Project 1.
There is no specific form.  
You can write what you want to write.  
Since this markdown file is just displayed on the screen, you can create an image or format that matches the format you want.  
In the case of the example, I briefly described the project introduction, technique, and period.  


## Techique
I wrote that I used python to run the project.  
You just need to describe how you made it.  


## Duration 
You can enter the period in a convenient format.   
You may specify only the duration of your work, assuming that you create a start date in the filename.  
