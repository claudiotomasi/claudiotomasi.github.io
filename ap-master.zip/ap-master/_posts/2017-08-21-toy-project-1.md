---
layout: post
title:  "Toy Project 1"
info: "toy project"
tech: "python3"
type: Toy
---

## Toy Project 1.
Creating a virtual project as a sample is difficult.  
So some of the samples will just copy the existing sample.  


## Tech
This is a project using Python3.  


## Duration
It seems to take about a week.
