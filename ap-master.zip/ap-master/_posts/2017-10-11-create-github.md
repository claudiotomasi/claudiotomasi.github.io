---
layout: post
title:  "Create github"
info: "Create new github repository"
tech: "none"
type: A Company
---

## Create 
This time I recorded the creation of the github account.  
I can not say this is a project, but I did not have a project to write.  

## Tech
There is no description because I created an account on the homepage.  

## Duration
It takes less than an hour to create an account.
