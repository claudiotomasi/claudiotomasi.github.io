---
layout: post
title:  "Reservation Bot"
info: "Restaurant Reservation Bot"
tech: "Python, Slack API"
type: B Company
---

## Reservation Bot 
This is just a project that suddenly reminds me.  
Of course I did not actually work, I wrote something plausible.  
To be honest, the project here is a virtual project.  
It's all fake.  


## Tech
I usually create a Bot with Slack and build it using the slack API.  
nd I used my favorite Python.  


## Duration
I'll make it in a day.  
