---
layout: post
title:  "Create github page"
info: "Create my github blog."
tech: "ruby, jekyll"
type: B Company
---

## Create github page 
This is a project for my github blog.  
I actually created a github page, but the contents are fake.  


## Tech
To create a github page, you need to know ruby and jekyll.  


## Duration
Well, about three days  
