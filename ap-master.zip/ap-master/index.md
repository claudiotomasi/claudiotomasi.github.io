---
layout: about 
---

# About Me
There is no specific format here. You can fill out the form you want.  
For example, you might want to write a brief introduction about your self, experience, interests, publications, and other information.  
I wrote "about me", "career", and "interests" on this page as an example.  

<br/>

# Career
* Second Company (2012/01 ~ )
  * Web Application Firewall
    * Developed TCP network acceleration module.
    * Developde Application User Interface.
* First Company (2011/01 ~ 2011/12)
  * VPN Development Company
  * Team Leader of VPN Development Div.

<br/>

# Interests
I am interested in technology trends.  
I'm not afraid to learn languages, but I enjoy using Python.  
I like to automate and reduce annoying things.  
